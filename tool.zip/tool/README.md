don't pick the number 1-3 or you'll ping the ip address.đ

credits to ebola man i love you gang❤️.

discord : no1knowss
snap : hacker20255
instagram : _anonymouswhitehat_ 

and also disable antivirus

